package com.dnerd.dipty.mynavigationapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Gallery_Clicked extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery__clicked);
    }
}
